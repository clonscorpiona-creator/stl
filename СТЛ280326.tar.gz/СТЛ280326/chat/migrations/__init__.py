# Migrations for chat app
